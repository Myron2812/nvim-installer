require'navigator'.setup({
  mason = true,
  icons = {
    icons = true,
    diagnostic_err = '🚫', --error symbol
    diagnostic_warn = '⚠️', --warning symbol
    diagnostic_virtual_text = '💡'
  }
})
