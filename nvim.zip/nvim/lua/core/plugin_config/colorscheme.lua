vim.o.termguicolors = true
vim.cmd('colorscheme citruszest')
