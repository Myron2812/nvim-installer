require("core.keymaps")
require("core.plugins")
require("core.plugin_config")
require("core.options")
